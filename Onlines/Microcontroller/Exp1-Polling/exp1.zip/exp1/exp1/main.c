/*
 * exp1.c
 *
 * Created: 1/21/2024 2:25:45 PM
 * Author : TTT
 */ 

#define F_CPU 1000000 
#include <avr/io.h> 
#include <util/delay.h> 
 
int main(void) 
{ 
    /* Replace with your application code */
	DDRB = 0x00;  
	DDRA = 0b00001111; 
	unsigned char count = 0 ; 
   
    while (1)  
    {
		
		if (PINB & 1) { 
		   count = (count + 3) % 16;
		   PORTA = count;
		      
		    _delay_ms(500);
			while (PINB & 1); 
		   
		} 
		else if (PINB & (1 << 1)) {
			count = (count + 16 - 3) % 16;
			PORTA = count; 
			
			 _delay_ms(500);
			while (PINB & (1 << 1));
		}
	} 
}